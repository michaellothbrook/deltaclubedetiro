<!-- Start Footer Section -->
<footer class="ftco-footer py-5">
		  <div class="container text-center">
		    <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Delta Clube de Tiro
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>

					  <ul class="ftco-footer-social p-0">
              <!-- <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li> -->
              <!-- <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li> -->
              <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
            </ul>
          </div>
        </div>
		  </div>
		</footer>
		<!-- End Footer Section -->
   

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="js/main.js"></script>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    
	$(document).ready(function () {
    $(".modal-wide").on("show.bs.modal", function() {
    var height = $(window).height() - 200;
    $(this).find(".modal-body").css("max-height", height);
    });
	});
    </script>


      <div id="modal1" class="modal fade">
        <div class="modal-dialog">
          <div class="modal-content bg-dark">
            <div class="">
              <button type="button" class="close text-center" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title text-center" style="color: #fff;">RIFLES/CARABINAS</h4>
            </div>
            <div class="modal-body">
              <p>Na verdade, Mundialmente o mais usado para se referir a fuzil é o termo Rifle. Sendo que Carabina ou Rifle são Designações usadas p/ armas de fogo portáteis, de cano Longo (maior que 28 cm). Podem ser de Repetição (bolt Action, Alavanca ou Corrediça "pump"), Semi-Automáticos ou totalmente automáticos. O termo Rifle ou Refle, são palavras de Origem Língua inglesa. A diferença entre RIFLE "fuzil" e CARABINA (carbine) é apenas o tamanho do cano, tendo a Carabina (carbine) cano menor que 46cm ou 18". Tanto RIFLE "fuzil" quanto a CARABINA para corretamente receberem essas designações precisam ter cano c/ alma raiada, sendo por definição "espingarda" apenas as armas de fogo c/ cano Longo de alma Lisa.

                  Eugene Stoner, um dos Maiores projetistas de Armas de todos os tempos, idealizou uma Arquitetura para Rifles, que ficou sendo uma das Duas mais conhecidas, o projeto recebeu a Designação de AR ArmaLite AR-15, atualmente de forma ERRADA, a mídia e tantos outros dizem se tratar de abreviação para Assalt Rifle, quando na verdade o Correto é ArmaLite RIFLE já que desde o inicio do projeto, o objetivo era uma Arma Segura, funcional e o + Leve possível.</p>
            </div>
            <div class="modal-footer">
              <button style="color: #fff" type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->



      <div id="modal2" class="modal fade">
        <div class="modal-dialog">
          <div class="modal-content bg-dark">
            <div class="">
              <button type="button" class="close text-center" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title text-center" style="color: #fff;">ESPINGARDAS</h4>
            </div>
            <div class="modal-body">
              <p>Uma espingarda é uma arma de fogo portátil de alma lisa, que utiliza como munição cartuchos de projéteis múltiplos ou de um único projétil concebido para se estabilizar no voo, compensando a ausência de raiamento do cano.[1] Tornou-se a principal arma pessoal dos exércitos, desde o final do século XVII, altura em que a espingarda de pederneira substituiu o mosquete. A baioneta que era costume afixar-lhe para a luta corpo a corpo tornou-se operacionalmente praticamente obsoleta.</p>
            </div>
            <div class="modal-footer">
              <button style="color: #fff" type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->


      <div id="modal3" class="modal fade">
        <div class="modal-dialog">
          <div class="modal-content bg-dark">
            <div class="">
              <button type="button" class="close text-center" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title text-center" style="color: #fff;">PISTOLAS</h4>
            </div>
            <div class="modal-body">
              <p>A Pistola é uma arma de fogo ou o feeder, leve, de cano curto. Uma pistola geralmente é uma arma pequena de boa empunhadura e rápido manuseio, feita originalmente para uso pessoal (uso por uma pessoa) em ações de pequeno alcance.</p>
            </div>
            <div class="modal-footer">
              <button style="color: #fff" type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->


      <div id="modal4" class="modal fade">
        <div class="modal-dialog">
          <div class="modal-content bg-dark">
            <div class="">
              <button type="button" class="close text-center" data-dismiss="modal" aria-hidden="true">&times;</button>
              <h4 class="modal-title text-center" style="color: #fff;">REVOLVERES</h4>
            </div>
            <div class="modal-body">
              <p>Um revólver (em inglês: revolver) é uma arma de fogo de repetição, de porte individual, normalmente com um só cano e com calibres variados. O depósito de cartuchos do revólver é constituído por um tambor ou cilindro giratório com várias câmaras ou culatras onde ficam os cartuchos (usualmente cinco ou seis, porém variando para mais ou para menos). O mecanismo de alimentação rotaciona este tambor um arco de revolução por disparo, de onde provém seu nome. Sistema moderno descende do projeto desenvolvido por Samuel Colt em 1836, embora o conceito existia há séculos antes da invenção de Colt. Revolveres são comumente armas de mão, porém outros tipos de armas podem ser consideradas revólveres também, como alguns rifles, lança-granadas e espingardas.Tem como excelente característica a confiabilidade no funcionamento,onde se destaca ante a pistola.</p>
            </div>
            <div class="modal-footer">
              <button style="color: #fff" type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

      <script src="<?=base_url('js/jquery.mask.js')?>"></script>
      <script>
        $(document).ready(function(){
            var behavior = function (val) {
                return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
            },
            options = {
                onKeyPress: function (val, e, field, options) {
                    field.mask(behavior.apply({}, arguments), options);
                }
            };

            $('#telefone').mask(behavior, options);

            
        })
      </script>

  </body>
</html>